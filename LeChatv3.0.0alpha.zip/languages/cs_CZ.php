<?php
//Did you translated LeChat into antoher language? -> https://github.com/LeNinjaHD/LeChat/issues/new/choose

//index.php
$loginfirst = 'Prosím nejdříve se <a href="login.php">přihlašte</a>.';
$welcome = "Vítej v <b>LeChat</b>";
$tochat = "Chat";

//logout.php
$alreadyloggedout = 'Již jsi odhlášen!';
$whatnow = "Nyní můžeš toto okno zavřít";

//chat.php
$settings = "Nastavení";
$loadmsg = "Načíst zprávy";
$send = "Poslat";

//register.php
$finished = 'Registrace dokončena. Nyní můžeš do <a href="chat.php">Chatu</a>.';

//settings.php
$yoursettings = "<b>Vaše nastavení:</b>";
$notset = "<b>Nemáte žádné nastavení!</b>";
$display_mode = "Zobrazovací módy: ";
$language = "Jazyk: ";
$changemode = "<b>Změnit zobrazovací mód:</b>";
$set = "Nastavit";
$de = "Němčina";
$en = "Angličtina";
$cz = "Čeština";
?>
