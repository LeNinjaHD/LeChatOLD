<?php
//Did you translated LeChat into antoher language? -> https://github.com/LeNinjaHD/LeChat/issues/new/choose

//index.php
$loginfirst = 'Please <a href="login.php">login</a> first.';
$welcome = "Welcome to <b>LeChat</b>";
$tochat = "To Chat";

//logout.php
$alreadyloggedout = 'You are already logged out!';
$whatnow = "You can close this Tab now!";

//chat.php
$settings = "Settings";
$loadmsg = "Load Messages";
$send = "Send";

//register.php
$finished = 'Registration completed. You can <a href="chat.php">Chat</a> now.';

//settings.php
$yoursettings = "<b>Your Settings:</b>";
$notset = "<b>NO SETTING CONFIGURED!</b>";
$display_mode = "Display-Modus: ";
$language = "Language: ";
$changemode = "<b>Change Display-Mode:</b>";
$set = "Set";
$de = "German";
$en = "English";
$cz = "Czech";
?>
