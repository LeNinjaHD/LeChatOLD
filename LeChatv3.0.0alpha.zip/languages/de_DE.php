<?php
//Did you translated LeChat into antoher language? -> https://github.com/LeNinjaHD/LeChat/issues/new/choose

//index.php
$loginfirst = 'Bitte zuerst <a href="login.php">einloggen</a>';
$welcome = "Herzlich Wilkommen bei <b>LeChat</b>";
$tochat = "Zum Chat";

//logout.php
$alreadyloggedout = 'Du hast dich bereits abgemeldet!';
$whatnow = "Sie können diesen Tab nun schließen!";

//chat.php
$settings = "Einstellungen";
$loadmsg = "Nachrichten laden";
$send = "Senden";

//register.php
$finished = 'Du wurdest erfolgreich registriert. <a href="chat.php">Zum Chat</a>';

//settings.php
$yoursettings = "<b>Deine Einstellungen:</b>";
$notset = "<b>KEINE EINSTELLUNG GESETZT!</b>";
$display_mode = "Anzeige-Modus: ";
$language = "Sprache: ";
$changemode = "<b>Anzeige-Modus ändern:</b>";
$set = "Einstellen";
$de = "Deutsch";
$en = "Englisch";
$cz = "Tschechisch";
?>
